# Fase 2
Usando la logica del Backend
se llama al metodo para su 
aplicacion con la Interfaz
GUI del Laboratorio
