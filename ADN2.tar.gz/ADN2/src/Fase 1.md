# Fase 1
Se Desarrolla una comparativa entre 2 bases nitrogenadas
de una secuencia de ADN de caracter nucleotido
Y se manda el parametro de mayor tamaño.
