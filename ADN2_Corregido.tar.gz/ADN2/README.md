# Decodificador_ADN-
Se realiza un decodificador para las Bases Nitrogenadas en un Secuencia de ADN

EL .JAR (ejecutable) se encuentra en el Dist.
